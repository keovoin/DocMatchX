from sqlalchemy import create_engine, Column, Integer, String, Text, DateTime
from sqlalchemy.orm import sessionmaker, declarative_base
from datetime import datetime
import os

DB_URL = os.getenv("DB_URL", "sqlite:///./data.db")
engine = create_engine(DB_URL, connect_args={"check_same_thread": False} if DB_URL.startswith("sqlite") else {})
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base = declarative_base()

class TemplateMapping(Base):
    __tablename__ = "template_mappings"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(200), unique=True, index=True, nullable=False)
    description = Column(String(500), default="")
    mapping_json = Column(Text, nullable=False)
    fixed_json = Column(Text, default="{}")
    created_by = Column(String(200), default="system")
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow)

class ValidationRun(Base):
    __tablename__ = "validation_runs"
    id = Column(Integer, primary_key=True, index=True)
    run_at = Column(DateTime, default=datetime.utcnow, index=True)
    user = Column(String(200), default="anonymous")
    excel_name = Column(String(500))
    pdf_name = Column(String(500))
    currency = Column(String(10))
    tolerance = Column(Integer)
    status = Column(String(20))   # PASS/FAIL
    total_excel = Column(Integer)
    total_pdf = Column(Integer)
    difference = Column(Integer)
    stats_json = Column(Text)     # JSON string
