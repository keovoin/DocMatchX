from fastapi import FastAPI, UploadFile, File, Form, Depends, HTTPException
from fastapi.responses import JSONResponse, PlainTextResponse, HTMLResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.sessions import SessionMiddleware
from typing import Optional
import tempfile, os, json
from io import BytesIO

from .models.schemas import ValidateResponse, TemplateIn, TemplateOut
from .services.excel_parse import read_excel_struct
from .services.pdf_extract import guess_pdf_text, find_grand_total, extract_simple_table_lines
from .services.matcher import compare_totals, match_records, parse_pdf_records
from .services.xml_convert import excel_to_xml_no_header
from .services.report import build_report_xlsx
from .db import Base, engine, SessionLocal, TemplateMapping, ValidationRun
from sqlalchemy.orm import Session
from datetime import datetime

from .auth import router as auth_router, get_current_user

api = FastAPI(title="MRBP Validate", version="1.1")
api.add_middleware(SessionMiddleware, secret_key=os.getenv("SESSION_SECRET", "change-me"))
api.include_router(auth_router)

api.mount("/ui", StaticFiles(directory="app/static", html=True), name="static")

Base.metadata.create_all(bind=engine)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@api.get("/", response_class=HTMLResponse)
def root():
    with open("app/static/index.html", "r", encoding="utf-8") as f:
        return f.read()

@api.post("/validate", response_model=ValidateResponse)
async def validate(
    excel_file: UploadFile = File(...),
    pdf_file: UploadFile = File(...),
    currency: Optional[str] = Form(default="AUTO"),
    tolerance_abs: Optional[int] = Form(default=0),
    user: dict = Depends(lambda: {"email":"anonymous"}),
):
    with tempfile.TemporaryDirectory() as td:
        x_path = os.path.join(td, excel_file.filename)
        p_path = os.path.join(td, pdf_file.filename)
        with open(x_path, "wb") as f: f.write(await excel_file.read())
        with open(p_path, "wb") as f: f.write(await pdf_file.read())

        x = read_excel_struct(x_path)
        pdf = guess_pdf_text(p_path)
        txt = pdf["text"]
        pdf_total = find_grand_total(txt)
        if currency == "AUTO":
            currency = pdf["currency"] if pdf["currency"] != "AUTO" else "KHR"
        summary = compare_totals(x["total"], pdf_total or 0, currency, int(tolerance_abs or 0))
        lines = extract_simple_table_lines(txt)
        pdf_recs = parse_pdf_records(lines)
        config = {"fuzzy_name": True, "name_threshold": 85, "date_window_days": 5, "tolerance_abs": int(tolerance_abs or 0)}
        line_cmp = match_records(x["rows"], pdf_recs, config)
        return ValidateResponse(summary=summary, line_comparison=line_cmp, duplicates=[], notes=[])

@api.post("/validate/report")
async def validate_with_report(
    excel_file: UploadFile = File(...),
    pdf_file: UploadFile = File(...),
    currency: Optional[str] = Form(default="AUTO"),
    tolerance_abs: Optional[int] = Form(default=0),
    user: dict = Depends(lambda: {"email":"anonymous"}),
    db: Session = Depends(get_db)
):
    with tempfile.TemporaryDirectory() as td:
        x_path = os.path.join(td, excel_file.filename)
        p_path = os.path.join(td, pdf_file.filename)
        with open(x_path, "wb") as f: f.write(await excel_file.read())
        with open(p_path, "wb") as f: f.write(await pdf_file.read())

        x = read_excel_struct(x_path)
        pdf = guess_pdf_text(p_path)
        txt = pdf["text"]
        lines = extract_simple_table_lines(txt)
        pdf_total = find_grand_total(txt)
        if currency == "AUTO":
            currency = pdf["currency"] if pdf["currency"] != "AUTO" else "KHR"
        summary = compare_totals(x["total"], pdf_total or 0, currency, int(tolerance_abs or 0))
        pdf_recs = parse_pdf_records(lines)
        config = {"fuzzy_name": True, "name_threshold": 85, "date_window_days": 5, "tolerance_abs": int(tolerance_abs or 0)}
        line_cmp = match_records(x["rows"], pdf_recs, config)

        run = ValidationRun(
            user=user.get("email","anonymous"),
            excel_name=excel_file.filename,
            pdf_name=pdf_file.filename,
            currency=currency,
            tolerance=int(tolerance_abs or 0),
            status=summary["status"],
            total_excel=summary["total_excel"],
            total_pdf=summary["total_pdf"],
            difference=summary["difference"],
            stats_json=json.dumps({"summary":summary, "lines":line_cmp})
        )
        db.add(run); db.commit()

        blob = build_report_xlsx(summary, line_cmp, [], lines)
        return StreamingResponse(BytesIO(blob), media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", headers={"Content-Disposition": 'attachment; filename="validation_report.xlsx"'})

@api.post("/extract-table")
async def extract_table(pdf_file: UploadFile = File(...), strategy: Optional[str] = Form(default="auto"), page_range: Optional[str] = Form(default=None)):
    with tempfile.TemporaryDirectory() as td:
        p_path = os.path.join(td, pdf_file.filename)
        with open(p_path, "wb") as f: f.write(await pdf_file.read())
        pdf = guess_pdf_text(p_path)
        lines = extract_simple_table_lines(pdf["text"])
        return JSONResponse({"lines": lines[:2000], "count": len(lines)})

@api.post("/convert-xml", response_class=PlainTextResponse)
async def convert_xml(excel_file: UploadFile = File(...), mapping_json: str = Form(...), fixed_json: Optional[str] = Form(default="{}")):
    mapping = json.loads(mapping_json)
    fixed = json.loads(fixed_json or "{}")
    with tempfile.TemporaryDirectory() as td:
        x_path = os.path.join(td, excel_file.filename)
        with open(x_path, "wb") as f: f.write(await excel_file.read())
        xml_text = excel_to_xml_no_header(x_path, mapping, fixed)
        return xml_text

# Template manager
@api.post("/templates", response_model=dict)
def create_template(payload: TemplateIn, db: Session = Depends(get_db), user: dict = Depends(lambda: {"email":"anonymous"})):
    if db.query(TemplateMapping).filter(TemplateMapping.name == payload.name).first():
        raise HTTPException(status_code=409, detail="Template name already exists.")
    t = TemplateMapping(name=payload.name, description=payload.description or "", mapping_json=json.dumps(payload.mapping_json, ensure_ascii=False), fixed_json=json.dumps(payload.fixed_json or {}, ensure_ascii=False), created_by=user.get("email","anonymous"))
    db.add(t); db.commit(); db.refresh(t)
    return {"id": t.id, "name": t.name}

@api.get("/templates", response_model=list[TemplateOut])
def list_templates(db: Session = Depends(get_db)):
    rows = db.query(TemplateMapping).order_by(TemplateMapping.updated_at.desc()).all()
    out = []
    for t in rows:
        out.append({
            "id": t.id,
            "name": t.name,
            "description": t.description,
            "mapping_json": json.loads(t.mapping_json),
            "fixed_json": json.loads(t.fixed_json or "{}"),
            "created_by": t.created_by,
            "created_at": t.created_at.isoformat(),
            "updated_at": t.updated_at.isoformat(),
        })
    return out

@api.get("/templates/{tid}", response_model=TemplateOut)
def get_template(tid: int, db: Session = Depends(get_db)):
    t = db.query(TemplateMapping).get(tid)
    if not t:
        raise HTTPException(status_code=404, detail="Not found")
    return {
        "id": t.id,
        "name": t.name,
        "description": t.description,
        "mapping_json": json.loads(t.mapping_json),
        "fixed_json": json.loads(t.fixed_json or "{}"),
        "created_by": t.created_by,
        "created_at": t.created_at.isoformat(),
        "updated_at": t.updated_at.isoformat(),
    }

@api.put("/templates/{tid}", response_model=dict)
def update_template(tid: int, payload: TemplateIn, db: Session = Depends(get_db)):
    t = db.query(TemplateMapping).get(tid)
    if not t:
        raise HTTPException(status_code=404, detail="Not found")
    t.name = payload.name
    t.description = payload.description or ""
    t.mapping_json = json.dumps(payload.mapping_json, ensure_ascii=False)
    t.fixed_json = json.dumps(payload.fixed_json or {}, ensure_ascii=False)
    t.updated_at = datetime.utcnow()
    db.commit()
    return {"ok": True}

@api.delete("/templates/{tid}", response_model=dict)
def delete_template(tid: int, db: Session = Depends(get_db)):
    t = db.query(TemplateMapping).get(tid)
    if not t:
        raise HTTPException(status_code=404, detail="Not found")
    db.delete(t); db.commit()
    return {"ok": True}
