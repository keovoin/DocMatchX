import os
from authlib.integrations.starlette_client import OAuth
from fastapi import Request, Depends, HTTPException, APIRouter
from starlette.responses import RedirectResponse

TENANT_ID = os.getenv("TENANT_ID")
CLIENT_ID = os.getenv("CLIENT_ID")
CLIENT_SECRET = os.getenv("CLIENT_SECRET")
REDIRECT_URI = os.getenv("REDIRECT_URI", "http://localhost:8000/auth/callback")
AUTHORITY = f"https://login.microsoftonline.com/{TENANT_ID}/v2.0" if TENANT_ID else None

router = APIRouter(prefix="/auth", tags=["auth"])
oauth = OAuth()
if TENANT_ID and CLIENT_ID and CLIENT_SECRET:
    oauth.register(
        name='azure',
        server_metadata_url=f'{AUTHORITY}/.well-known/openid-configuration',
        client_id=CLIENT_ID,
        client_secret=CLIENT_SECRET,
        client_kwargs={'scope': 'openid email profile'}
    )

@router.get("/login")
async def login(request: Request):
    if not TENANT_ID:
        raise HTTPException(status_code=500, detail="SSO not configured")
    redirect_uri = REDIRECT_URI
    return await oauth.azure.authorize_redirect(request, redirect_uri)

@router.get("/callback")
async def auth_callback(request: Request):
    token = await oauth.azure.authorize_access_token(request)
    user = token.get('userinfo') or {}
    request.session['user'] = {
        "name": user.get("name"),
        "email": user.get("email") or user.get("preferred_username"),
        "oid": user.get("oid")
    }
    return RedirectResponse(url="/ui")

def get_current_user(request: Request):
    user = request.session.get('user')
    if not user:
        raise HTTPException(status_code=401, detail="Not authenticated")
    return user
