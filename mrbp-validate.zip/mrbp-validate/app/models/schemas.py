from pydantic import BaseModel, Field
from typing import Optional, Dict, List, Any

class ValidateResponse(BaseModel):
    summary: Dict[str, Any]
    line_comparison: List[Dict[str, Any]] = []
    duplicates: List[Dict[str, Any]] = []
    notes: List[str] = []

class ExtractOptions(BaseModel):
    strategy: str = Field(default="auto", description="auto|text|ocr")
    page_range: Optional[str] = None

class XmlMapping(BaseModel):
    mapping: Dict[str, str]
    fixed: Dict[str, str] = Field(default_factory=dict)
    date_format: Optional[str] = "YYYY-MM-DD"

class TemplateIn(BaseModel):
    name: str
    description: Optional[str] = ""
    mapping_json: Dict[str, str]
    fixed_json: Optional[Dict[str, str]] = {}

class TemplateOut(BaseModel):
    id: int
    name: str
    description: str
    mapping_json: Dict[str, str]
    fixed_json: Dict[str, str]
    created_by: str
    created_at: str
    updated_at: str
