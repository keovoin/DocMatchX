from typing import Dict, Any, List
from rapidfuzz import fuzz
import re
from datetime import datetime
from .utils import to_int_safe

ID_PAT = re.compile(r"\d{3,5}-\d{1,3}-\d{3,6}(?:-\d+)*")
DATE_PAT = re.compile(r"(20\d{2}[-/]\d{1,2}[-/]\d{1,2}| \d{1,2}[-/]\d{1,2}[-/](20\d{2}))")

def compare_totals(excel_total: int, pdf_total: int, currency: str, tolerance_abs: int = 0) -> Dict[str, Any]:
    diff = excel_total - pdf_total
    status = "PASS" if abs(diff) <= tolerance_abs else "FAIL"
    return {
        "currency": currency,
        "total_excel": excel_total,
        "total_pdf": pdf_total,
        "difference": diff,
        "tolerance_abs": tolerance_abs,
        "status": status
    }

def parse_pdf_records(lines: List[str]) -> List[Dict[str, Any]]:
    recs = []
    for ln in lines:
        amounts = []
        for m in re.findall(r"\d{1,3}(?:,\d{3})+", ln):
            n = to_int_safe(m)
            if n:
                amounts.append(n)
        ids = ID_PAT.findall(ln)
        dt = None
        md = DATE_PAT.search(ln)
        if md:
            dt = md.group(0).replace('/', '-').strip()
        name = ln
        recs.append({"line": ln, "ids": ids, "amounts": amounts, "date": dt, "name": name})
    return recs

def match_records(excel_rows: List[Dict[str, Any]], pdf_recs: List[Dict[str, Any]], config: Dict[str, Any]) -> List[Dict[str, Any]]:
    fuzzy = config.get("fuzzy_name", True)
    th = config.get("name_threshold", 85)
    date_win = config.get("date_window_days", 5)
    tol = config.get("tolerance_abs", 0)
    out = []
    for r in excel_rows:
        amt = r["amount"]
        rid = (r.get("id") or "").strip()
        rname = (r.get("name") or "").strip()
        rdate = r.get("date")
        rdate_obj = None
        if rdate:
            try:
                rdate_obj = datetime.fromisoformat(rdate)
            except:
                pass
        best = None
        best_score = -1
        for pr in pdf_recs:
            found_amt = any(abs(amt - a) <= tol for a in pr["amounts"])
            if not found_amt:
                continue
            score = 0
            if rid and any(rid in pid for pid in pr["ids"]):
                score += 50
            if fuzzy and rname:
                score += fuzz.token_set_ratio(rname, pr["name"])
            if rdate_obj and pr.get("date"):
                try:
                    from datetime import datetime
                    pdate = datetime.fromisoformat(pr["date"])
                    if abs((pdate - rdate_obj).days) <= date_win:
                        score += 20
                except:
                    pass
            if score > best_score:
                best_score = score
                best = pr
        out.append({
            "excel_row": r["row_index"],
            "id": rid,
            "name_excel": rname,
            "amount_excel": amt,
            "match_line": best["line"] if best else None,
            "amount_pdf": amt if best else None,
            "score": best_score if best else 0,
            "status": "MATCH" if best else "NOT_FOUND"
        })
    return out
