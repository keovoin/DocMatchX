import pandas as pd
from io import BytesIO

def build_report_xlsx(summary: dict, line_cmp: list, duplicates: list, raw_lines: list[str]) -> bytes:
    bio = BytesIO()
    with pd.ExcelWriter(bio, engine="openpyxl") as w:
        pd.DataFrame([summary]).to_excel(w, sheet_name="Summary", index=False)
        pd.DataFrame(line_cmp).to_excel(w, sheet_name="LineComparison", index=False)
        pd.DataFrame(duplicates or []).to_excel(w, sheet_name="Duplicates", index=False)
        pd.DataFrame({"pdf_lines": raw_lines}).to_excel(w, sheet_name="RawPDF", index=False)
    bio.seek(0)
    return bio.read()
