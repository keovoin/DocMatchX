import fitz
import io
from PIL import Image
import pytesseract
import re
from typing import Dict, Any, List
from .utils import normalize_digits, to_int_safe, detect_currency

def extract_pdf_text(path: str) -> str:
    doc = fitz.open(path)
    text = ""
    for page in doc:
        t = page.get_text("text")
        text += t + "
"
    return text

def ocr_pdf_to_text(path: str, lang: str = "eng+khm") -> str:
    doc = fitz.open(path)
    buf = []
    for page in doc:
        pix = page.get_pixmap(dpi=300)
        img = Image.open(io.BytesIO(pix.tobytes("png")))
        t = pytesseract.image_to_string(img, lang=lang)
        buf.append(t)
    return "
".join(buf)

def guess_pdf_text(path: str) -> Dict[str, Any]:
    text_native = extract_pdf_text(path)
    if len(re.findall(r"\d", text_native)) < 20:
        text_ocr = ocr_pdf_to_text(path)
        text = text_native + "
" + text_ocr
    else:
        text = text_native
    text = normalize_digits(text)
    return {"text": text, "currency": detect_currency(text)}

def find_grand_total(text: str) -> int | None:
    for m in re.findall(r"\d{1,3}(?:,\d{3}){2,}", text):
        n = to_int_safe(m)
        if n and n > 1_000_000:
            return n
    for m in re.findall(r"\d{7,}", text):
        n = to_int_safe(m)
        if n and n > 1_000_000:
            return n
    return None

def extract_simple_table_lines(text: str) -> List[str]:
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    return lines
