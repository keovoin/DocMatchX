import pandas as pd
from typing import Dict, Any
from .utils import to_int_safe, normalize_digits
import re
from datetime import datetime

ID_PAT = re.compile(r"\d{3,5}-\d{1,3}-\d{3,6}(?:-\d+)*")

def parse_date_cell(v) -> str | None:
    if pd.isna(v): return None
    if isinstance(v, (int, float)):
        try:
            return pd.to_datetime(v, unit='d', origin='1899-12-30').date().isoformat()
        except:
            return None
    s = normalize_digits(str(v)).replace('/', '-').strip()
    try:
        return pd.to_datetime(s, errors='coerce').date().isoformat()
    except:
        return None

def read_excel_struct(path: str) -> Dict[str, Any]:
    df = pd.read_excel(path, header=None)
    rows = []
    for i in range(len(df)):
        row_str = " ".join([normalize_digits(str(x)) for x in df.iloc[i, :].tolist() if pd.notna(x)])
        nums = []
        for v in df.iloc[i, :].tolist():
            if pd.isna(v): continue
            if isinstance(v, (int, float)):
                nums.append(int(v))
            else:
                n = to_int_safe(str(v))
                if n is not None:
                    nums.append(n)
        candidates = [x for x in nums if 100_000 <= x <= 1_000_000_000]
        if not candidates:
            continue
        amt = max(candidates)
        idm = ID_PAT.search(row_str)
        rid = idm.group(0) if idm else None
        parts = [p for p in row_str.split() if not to_int_safe(p)]
        name = " ".join(parts[:6]) if parts else ""
        rdate = None
        for v in df.iloc[i, :].tolist():
            d = parse_date_cell(v)
            if d:
                rdate = d; break
        rows.append({"row_index": i, "amount": amt, "id": rid, "name": name, "date": rdate})
    total = sum([r["amount"] for r in rows])
    return {"rows": rows, "count": len(rows), "total": total}
