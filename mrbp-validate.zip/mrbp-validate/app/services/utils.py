import re

KHMER_DIGITS = {
    "០": "0","១": "1","២": "2","៣": "3","៤": "4",
    "៥": "5","៦": "6","៧": "7","៨": "8","៩": "9"
}

def normalize_digits(s: str) -> str:
    if not isinstance(s, str):
        s = str(s)
    for k,v in KHMER_DIGITS.items():
        s = s.replace(k, v)
    return s

def to_int_safe(s: str):
    s = normalize_digits(s)
    s = s.replace(',', '').strip()
    if re.fullmatch(r"-?\d+", s):
        return int(s)
    return None

def detect_currency(text: str) -> str:
    t = text.upper()
    if "USD" in t or "$" in t:
        return "USD"
    if "KHR" in t or "៛" in t or "RIEL" in t:
        return "KHR"
    return "AUTO"
