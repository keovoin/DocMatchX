import pandas as pd
from lxml import etree
from typing import Dict
from .utils import normalize_digits

def excel_to_xml_no_header(xlsx_path: str, mapping: Dict[str, str], fixed: Dict[str, str] | None = None) -> str:
    df = pd.read_excel(xlsx_path)
    out_parts = []
    for _, row in df.iterrows():
        rec = etree.Element("Record")
        for tag, src in mapping.items():
            if src in df.columns:
                val = row[src]
            else:
                idx = ord(src.upper()) - ord('A')
                val = row.iloc[idx] if idx < len(row) else ""
            if pd.isna(val):
                val = ""
            etree.SubElement(rec, tag).text = normalize_digits(str(val)).strip()
        if fixed:
            for tag, val in fixed.items():
                etree.SubElement(rec, tag).text = str(val)
        out_parts.append(etree.tostring(rec, encoding="unicode"))
    return "".join(out_parts)
